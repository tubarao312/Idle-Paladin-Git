CONTACT:

E-Mail is my preferred method of contact.
If you contact me via E--Mail, please make sure that the subject matter is well defined.
thomas.feichtmeir@gmx.at
cyangmou@gmx-topmail.de



SOCIAL MEDIA:
if you want to follow me on Social media, I am mostly active on those pages:

Twitter:
https://twitter.com/cyangmou

Deviantart:
https://www.deviantart.com/cyangmou



MAILLIST:
Additionally please consider signing up to my Maillist.
I only use it for important announcements - no spam will be sent, I promise.

https://t.co/M9wmf2ds6O